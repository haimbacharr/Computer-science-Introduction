#include"Head1.h"

void push(PStack S, int new_elem)
{
	Item* temp;

	if (S->size == NUM) //in case that the list is empty
	{
		printf("\nCannot push element, the stack is full!\n");
	}
	else
	{
		if (!(temp = (Item*)malloc(sizeof(Item))))
		{
			DeleteList(S); //in case that allocation failed
			Error_Msg("Allocation failed!");
		}
		temp->num = new_elem; // getting the new elem to the new node
		temp->next = NULL;
		if (S->head == NULL)
		{
			S->head = temp; // add the new node as first
			S->size++;
			fprintf(stdout, "%d Is inserted\n", new_elem);
		}
		else
		{
			temp->next = S->head; 
			S->head = temp; // point head to the new node that its first node now
			S->size++;
			fprintf(stdout, "%d Is inserted\n", new_elem);
		}

	}
	if (S->size == NUM)
	{
		printf("\nCannot push element, the stack is full!\n\n");
	}
}

int Pop(PStack S, int* del_value)
{
	Item* temp;
	if (S->head == NULL)
	{
		printf("The stack is empty!\n");
		return 0;
	}
	else
	{
		temp = S->head;
		*del_value = temp->num;
		S->head = S->head->next;
		free(temp); // delete the first node (LIFO)
		S->size--;
		return 1;
	}


}
void DeleteList(PStack L)
{
	Item* temp;
	while (L->head)
	{
		temp = L->head;
		L->head = L->head->next;
		free(temp);
	}
}
void Error_Msg(char* msg)
{
	printf("\n%s", msg);
	exit(1);
}