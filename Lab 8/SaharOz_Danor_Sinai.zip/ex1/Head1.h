#ifndef head2
#define head2

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#define NUM 4

typedef struct Item {
	int num;
	struct Item* next;
}Item;

typedef struct Stack {
	Item* head;
	int size;         //a current number of items
}Stack, * PStack;

void push(PStack S, int new_elem);
void DeleteList(Stack* L);
void Error_Msg(char* msg);

#endif // !head2
