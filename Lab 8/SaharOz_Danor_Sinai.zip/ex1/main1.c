#include"Head1.h"

void main()
{
	int arr[NUM] = { 1,2,3,4 }, i, flag;
	Stack S;
	S.head = NULL;
	S.size = 0;
	for (i = 0; i < NUM; i++)
	{
		push(&S, arr[i]);
	}
	for (i = 0; i < NUM; i++)
	{
		flag=Pop(&S, &arr[i]);
		if (flag)
		{
			fprintf(stdout, "%d Is delleted!\n", arr[i]);
		}
		if (S.size == 0)
			fprintf(stdout, "\nCannot pop elemnt, the stuck is empty!\n");
	}

}
