#include "head2.h"

void InitStack(PStack s, int size)
{
	s->size = size;
	s->count = 0;
	s->top = 0;
	s->Array = (int*)malloc(sizeof(int)); //memory allocation the the array
	if (s->Array == NULL)
	{
		printf("memory allocation failed.");
		exit(1);
	}
}
void Push(PStack s, int new_elem)
{
	if (s->count < s->size)
	{
		s->Array[s->top] = new_elem; // add new elem to the start
		s->count++;
		s->top++;
	}
	else
	{
		printf("stack is full\n");
		return;
	}
}
int Pop(PStack s, int* del_value)
{
	*del_value = s->Array[s->count];
	if (s->count>0) //checking if the stack is empty
	{
		s->top--;
		*del_value = s->Array[s->top]; //delete from the start
		s->count--;
		return 1;
	}
	else
	{
		printf("the stack is empty\n");
		free(&s->Array);// in case that the stack is empty
		exit(1);
	}
}