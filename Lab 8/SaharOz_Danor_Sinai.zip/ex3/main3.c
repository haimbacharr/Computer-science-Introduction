#include"Header3.h"
void main()
{
	Queue Q;
	int arr[NUM] = { 1,2,3,4 }, i, flag;

	Q.head = NULL;
	Q.tail = NULL;
	Q.size = 0;

	for (i = 0; i < NUM; i++)
	{
		Enqueue(&Q, arr[i]);
	}
	fprintf(stdout, "\n");
	for (i = 0; i < NUM; i++)
	{
		flag = Dequeue(&Q, &arr[i]);
		if (flag)
		{
			fprintf(stdout, "%d Is delleted!\n", arr[i]);
		}
		if (Q.size == 0)
			fprintf(stdout, "\nCannot pop elemnt, the queue is empty!\n");
	}
}
