#include"Header3.h"
void Enqueue(PQue Q, int   new_elem)
{
	Item* temp;
	if (Q->size == NUM)
	{
		printf("\nCannot push element, the queue is full!\n");
	}
	else
	{
		if (!(temp = (Item*)malloc(sizeof(Item)))) // for "create" new node in the list
		{
			DeleteList(Q); // if allocation failed
			Error_Msg("Allocation failed!");
		}
		temp->num = new_elem; // getting the new num to the node
		temp->next = NULL;
		if (Q->head == NULL) // in case the lise is empty
		{
			Q->head = temp; // the first node is temp
			Q->tail = temp; // also the final node is temp
			Q->size++;
			fprintf(stdout, "%d Is inserted\n", new_elem);
		}
		else {
			Q->tail->next = temp; // adding new note to the end
			Q->tail = temp; // tail now point to the final node
			Q->size++;
			fprintf(stdout, "%d Is inserted\n", new_elem); // print the inserted item
		}
	}
}
int Dequeue(PQue Q, int* del_value)
{
	Item* temp;
	if (Q->head == NULL) // in case that the list is empty
	{
		printf("The queue is empty!\n");
		return 0;
	}
	else
	{
		temp = Q->head; 
		*del_value = Q->head->num;
		Q->head = Q->head->next;
		free(temp); // delete the first item in the list(the node that inserted first (FIFO))
		Q->size--;
	}
}
void DeleteList(PQue Q)
{
	Item* temp;
	while (Q->head)
	{
		temp = Q->head;
		Q->head = Q->head->next;
		free(temp);
	}
}
void Error_Msg(char* msg)
{
	printf("\n%s", msg);
	exit(1);
}
